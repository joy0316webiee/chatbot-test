export const apiUrl = 'http://www.mocky.io/v2/5cee37a5300000253a6e99af';
